# xymap
data processing tools
Bivariate colormap solutions. Inspired by [xycmap](https://github.com/rbjansen/xycmap).
